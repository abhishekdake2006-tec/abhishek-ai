import 'package:flutter/material.dart';

void main() => runApp(const AbhishekApp());

const kBg = Color(0xFF0A1128);
const kCard = Color(0xFF14203F);
const kAccent = Color(0xFF3D8BFF);

class Tool {
  final IconData icon;
  final List<String> names; // en, hi, mr
  const Tool(this.icon, this.names);
}

const tools = <Tool>[
  Tool(Icons.smart_toy, ['AI Chat', 'एआई चैट', 'एआय चॅट']),
  Tool(Icons.dashboard, ['DEKZA Dashboard', 'DEKZA डैशबोर्ड', 'DEKZA डॅशबोर्ड']),
  Tool(Icons.local_shipping, ['Suppliers', 'सप्लायर', 'पुरवठादार']),
  Tool(Icons.inventory_2, ['Products', 'प्रोडक्ट्स', 'उत्पादने']),
  Tool(Icons.campaign, ['Marketing', 'मार्केटिंग', 'मार्केटिंग']),
  Tool(Icons.chat, ['WhatsApp', 'WhatsApp', 'WhatsApp']),
  Tool(Icons.camera_alt, ['Instagram', 'Instagram', 'Instagram']),
  Tool(Icons.facebook, ['Facebook', 'Facebook', 'Facebook']),
  Tool(Icons.support_agent, ['Customer Support', 'ग्राहक सहायता', 'ग्राहक सहाय्य']),
  Tool(Icons.track_changes, ['Order Tracking', 'ऑर्डर ट्रैकिंग', 'ऑर्डर ट्रॅकिंग']),
  Tool(Icons.two_wheeler, ['Delivery Ops', 'डिलीवरी', 'डिलिव्हरी']),
  Tool(Icons.checklist, ['Personal Tasks', 'व्यक्तिगत कार्य', 'वैयक्तिक कामे']),
  Tool(Icons.verified_user, ['Approval Center', 'अनुमोदन केंद्र', 'मंजुरी केंद्र']),
  Tool(Icons.bar_chart, ['Reports', 'रिपोर्ट', 'अहवाल']),
  Tool(Icons.history, ['Activity History', 'गतिविधि इतिहास', 'हालचाल इतिहास']),
  Tool(Icons.settings, ['Settings', 'सेटिंग्स', 'सेटिंग्ज']),
];

const langNames = ['English', 'हिंदी', 'मराठी'];
const soon = [
  'Connects to the backend in the next step',
  'अगले चरण में बैकएंड से जुड़ेगा',
  'पुढच्या टप्प्यात बॅकएंडशी जोडले जाईल'
];
const approveT = ['Approve', 'मंजूर', 'मंजूर करा'];
const rejectT = ['Reject', 'अस्वीकार', 'नाकारा'];
const pendingT = ['Pending approvals', 'प्रतीक्षित अनुमोदन', 'प्रलंबित मंजुऱ्या'];
const askT = ['Type a message...', 'संदेश लिखें...', 'संदेश लिहा...'];

class AbhishekApp extends StatefulWidget {
  const AbhishekApp({super.key});
  @override
  State<AbhishekApp> createState() => _AbhishekAppState();
}

class _AbhishekAppState extends State<AbhishekApp> {
  int lang = 2;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ABHISHEK AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(primary: kAccent, surface: kCard),
        appBarTheme: const AppBarTheme(backgroundColor: kBg, elevation: 0),
        drawerTheme: const DrawerThemeData(backgroundColor: kBg),
      ),
      home: Home(lang: lang, onLang: (v) => setState(() => lang = v)),
    );
  }
}

class Home extends StatefulWidget {
  final int lang;
  final ValueChanged<int> onLang;
  const Home({super.key, required this.lang, required this.onLang});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int sel = 0;

  Widget body() {
    if (sel == 0) return ChatScreen(lang: widget.lang);
    if (sel == 12) return ApprovalScreen(lang: widget.lang);
    if (sel == 15) {
      return ListView(padding: const EdgeInsets.all(16), children: [
        for (var i = 0; i < 3; i++)
          Card(
            color: kCard,
            child: ListTile(
              title: Text(langNames[i]),
              trailing: Icon(widget.lang == i ? Icons.radio_button_checked : Icons.radio_button_off, color: kAccent),
              onTap: () => widget.onLang(i),
            ),
          ),
      ]);
    }
    final t = tools[sel];
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(t.icon, size: 72, color: kAccent),
        const SizedBox(height: 16),
        Text(t.names[widget.lang], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(soon[widget.lang], style: const TextStyle(color: Colors.white54)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tools[sel].names[l])),
      drawer: Drawer(
        child: SafeArea(
          child: Column(children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF1B3A8A), kBg])),
              child: const Text('ABHISHEK AI', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 2)),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: tools.length,
                itemBuilder: (c, i) => ListTile(
                  leading: Icon(tools[i].icon, color: sel == i ? kAccent : Colors.white70),
                  title: Text(tools[i].names[l]),
                  selected: sel == i,
                  onTap: () {
                    setState(() => sel = i);
                    Navigator.pop(context);
                  },
                ),
              ),
            ),
          ]),
        ),
      ),
      body: body(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final int lang;
  const ChatScreen({super.key, required this.lang});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ctrl = TextEditingController();
  final msgs = <MapEntry<bool, String>>[];

  void send() {
    final s = ctrl.text.trim();
    if (s.isEmpty) return;
    setState(() {
      msgs.add(MapEntry(true, s));
      msgs.add(MapEntry(false, soon[widget.lang]));
      ctrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: msgs.length,
          itemBuilder: (c, i) {
            final m = msgs[i];
            return Align(
              alignment: m.key ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: m.key ? kAccent : kCard, borderRadius: BorderRadius.circular(14)),
                child: Text(m.value),
              ),
            );
          },
        ),
      ),
      SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: ctrl,
                onSubmitted: (_) => send(),
                decoration: InputDecoration(
                  hintText: askT[widget.lang],
                  filled: true,
                  fillColor: kCard,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                ),
              ),
            ),
            IconButton(onPressed: send, icon: const Icon(Icons.send, color: kAccent)),
          ]),
        ),
      ),
    ]);
  }
}

class ApprovalScreen extends StatefulWidget {
  final int lang;
  const ApprovalScreen({super.key, required this.lang});
  @override
  State<ApprovalScreen> createState() => _ApprovalScreenState();
}

class _ApprovalScreenState extends State<ApprovalScreen> {
  final items = <String>[
    'WhatsApp: send offer to 120 customers',
    'Instagram: publish new product post',
    'Supplier: place order #1042',
  ];

  @override
  Widget build(BuildContext context) {
    final l = widget.lang;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(pendingT[l], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      for (final it in List.of(items))
        Card(
          color: kCard,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(it),
              const SizedBox(height: 8),
              Row(children: [
                ElevatedButton(onPressed: () => setState(() => items.remove(it)), child: Text(approveT[l])),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: () => setState(() => items.remove(it)), child: Text(rejectT[l])),
              ]),
            ]),
          ),
        ),
    ]);
  }
}
